Lots of useful functions for bivariate survival data
